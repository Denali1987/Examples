import 'react-native-reanimated';
import {
    StyleSheet,
    View,
    Pressable,
    Image,
    Text,
} from 'react-native';
import MoreInformationButton from '../components/MoreInformationButton';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer'

const HomeScreen = () => {
    const artImg = require('../assets/images/art.png')
    return (
        <View style={styles.mainContainerHome}>
            <Image
                source={artImg}
                style={[styles.Imgs]}
            />
            <MoreInformationButton
                title="More Information"
                url="https://www.artic.edu/"
            />
        </View >

    );
};

const MagScreen = () => {
    const magImg = require('../assets/images/mile.png')
    return (
        <View style={styles.mainContainerHome}>
            <Image
                source={magImg}
                style={[styles.Imgs]}
            />
            <MoreInformationButton
                title="More Information"
                url="https://www.themagnificentmile.com/"
            />
        </View>
    )
}

const NavScreen = () => {
    const navImg = require('../assets/images/pier.png')
    return (
        <View style={styles.mainContainerHome}>
            <Image
                source={navImg}
                style={[styles.Imgs]}
            />
            <MoreInformationButton
                title="More Information"

                url="https://navypier.org/"
            />
        </View>
    )
}

const WatScreen = () => {
    const watImg = require('../assets/images/water.png')
    return (
        <View style={styles.mainContainerHome}>
            <Image
                source={watImg}
                style={[styles.Imgs]}
            />
            <MoreInformationButton
                title="More Information"

                url="https://www.chicago.gov/city/en/depts/dca/supp_info/city_gallery_in_thehistoricwatertower.html"
            />
        </View>
    )
}

const WilScreen = () => {
    const magImg = require('../assets/images/willis.png')
    return (
        <View style={styles.mainContainerHome}>
            <Image
                source={magImg}
                style={[styles.Imgs]}
            />
            <MoreInformationButton
                title="More Information"
                url="https://www.willistower.com/"
            />

        </View>
    )
}







const Stack = createStackNavigator();
function HomeStack() {
    return (

        <Stack.Navigator>
            <Stack.Screen
                name="ArtInstituteOfChicago"
                component={HomeScreen}
                options={{ headerShown: false }}
            />
        </Stack.Navigator>
    );
}
function MagStack() {
    return (

        <Stack.Navigator>
            <Stack.Screen
                name="MagnificentMile"
                component={MagScreen}
                options={{ headerShown: false }}
            />
        </Stack.Navigator>
    );
}
function NavStack() {
    return (

        <Stack.Navigator>
            <Stack.Screen
                name="NavyPier"
                component={NavScreen}
                options={{ headerShown: false }}
            />
        </Stack.Navigator>
    );
}
function WatStack() {
    return (

        <Stack.Navigator>
            <Stack.Screen
                name="WaterTower"
                component={WatScreen}
                options={{ headerShown: false }}
            />
        </Stack.Navigator>
    );
}
function WilStack() {
    return (

        <Stack.Navigator>
            <Stack.Screen
                name="WillisTower"
                component={WilScreen}
                options={{ headerShown: false }}
            />
        </Stack.Navigator>
    );
}

const Drawer = createDrawerNavigator();

function MyDrawer() {
    return (
        <Drawer.Navigator initialRouteName="Art Institute of Chicago">
            <Drawer.Screen
                name="Art Institute of Chicago"
                component={HomeStack}
                options={{ drawerLabel: 'Art Institute of Chicago' }}
            />
            <Drawer.Screen
                name="Magnificent Mile"
                component={MagStack}
                options={{ drawerLabel: 'Magnificent Mile' }}
            />
            <Drawer.Screen
                name="Navy Pier"
                component={NavStack}
                options={{ drawerLabel: 'Navy Pier' }}
            />
            <Drawer.Screen
                name="Water Tower"
                component={WatStack}
                options={{ drawerLabel: 'Water Tower' }}
            />
            <Drawer.Screen
                name="Willis Tower"
                component={WilStack}
                options={{ drawerLabel: 'Willis Tower' }}
            />
        </Drawer.Navigator>

    );
}

export default function App() {
    return (
        //<NavigationContainer> I believe that expo-router has something to do with why I don't need this?
        <MyDrawer />
        //</NavigationContainer>

    )
}

const styles = StyleSheet.create({
    mainContainerHome: {
        flex: 1,
        backgroundColor: 'white',
        alignItems: 'center',
        justifyContent: 'center',
    },
    h2: {
        textAlign: 'left',
        paddingLeft: 59,
        fontSize: 30,
    },
    titleHome: {
        //backgroundColor: '#f4511e',
        //color: '#fff',
        fontSize: 20,
        fontWeight: 'bold',
        padding: 20,
        paddingTop: 30,
        marginTop: 30,
        textAlign: 'left',
        width: '100%',
    },
    Imgs: {
        width: 240,
        height: 360
    },
});