import React from 'react';
import { Pressable, Text, StyleSheet } from 'react-native';
import { Linking } from 'react-native';

interface ButtonProps {
    title: string;
    url: string;
}

const MoreInformationButton: React.FC<ButtonProps> = ({ title, url }) => {
    const handlePress = () => {
        Linking.openURL(url).catch(err => console.error("Couldn't load page", err));
    };
    return (
        <Pressable style={styles.button} onPress={handlePress}>
            <Text style={styles.buttonText}>{title}</Text>
        </Pressable>
    );
};

const styles = StyleSheet.create({
    button: {
        backgroundColor: '#3598db',
        paddingVertical: 12,
        paddingHorizontal: 20,
        borderRadius: 3,
        marginTop: 20,
    },
    buttonText: {
        color: 'white',
        fontSize: 16,
        textAlign: 'center',
    },
});

export default MoreInformationButton;
