import { StyleSheet, Dimensions } from 'react-native';

const { width, height } = Dimensions.get('window');

export const styles = StyleSheet.create({
    main: {
        flex: 1,
        backgroundColor: '#fdf7dd',
        padding: 0,
        alignItems: 'center',
        width: '100%',
    },

    h1Wrapper: {
        backgroundColor: '#fdf7dd',
        width: '100%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingHorizontal: width * 0.05,
    },

    logo: {
        width: width * 0.2,
        height: height * 0.1,
    },

    h1: {
        backgroundColor: '#fdf7dd',
        color: 'black',
        fontSize: 48,
        fontWeight: 'bold',
        padding: width * 0.05,
        //paddingTop: height * 0.05,
        textAlign: 'center',
        textShadowColor: '#bc1e0c',
        textShadowOffset: { width: 2, height: 2 },
        textShadowRadius: 10,
        fontFamily: 'serif',
    },

    lineBreak: {
        width: '100%',
        height: 2,
        backgroundColor: 'black',
        marginVertical: 10,
        alignItems: 'center',
    },

    scrollContent: {
        alignItems: 'center',
        paddingBottom: 20,
    },

    h2Wrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        width: '90%',
        marginBottom: 0,
    },

    h2: {
        fontSize: 30,
        fontWeight: 'bold',
        textAlign: 'left',
        textShadowColor: '#bc1e0c',
        textShadowOffset: { width: 2, height: 2 },
        textShadowRadius: 10,
        fontFamily: 'serif',
    },

    viewButton: {
        marginTop: 10,
        paddingVertical: 8,
        paddingHorizontal: 15,
        borderRadius: 5,
        alignSelf: 'flex-start',
    },

    viewButtonText: {
        color: 'black',
        fontSize: 16,
        fontWeight: 'normal',
    },

    formWrapper: {
        width: '90%',
        marginTop: 20,
    },

    input: {
        height: 50,
        borderColor: '#ccc',
        borderWidth: 1,
        borderRadius: 0,
        marginTop: 15,
        marginBottom: 15,
        paddingHorizontal: 10,
        backgroundColor: '#fff',
    },

    textArea: {
        height: 100,
        textAlignVertical: 'top',
    },

    buttonRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 20,
        alignItems: 'flex-end',
        width: '50%',
    },

    button: {
        flex: 1,
        paddingVertical: 12,
        marginHorizontal: 5,
        width: 150,
        marginLeft: 'auto',
        borderRadius: 5,
        alignItems: 'center',
    },

    buttonText: {
        color: 'black',
        fontSize: 16,
        fontWeight: 'normal',
    },

    entry: {
        padding: 20,
        marginBottom: 10,
        borderWidth: 1,
        borderColor: 'black',
        borderRadius: 0,
        width: '99%',
    },

    entryLabel: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#b00e0c',
    },

    entryText: {
        fontSize: 16,
        color: 'black',
        marginBottom: 1,
    },
});

export const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        height: 55,
        borderColor: '#ccc',
        borderWidth: 1,
        borderRadius: 5,
        marginBottom: 15,
        paddingHorizontal: 10,
        backgroundColor: '#bc1e0c',
    },
    inputAndroid: {
        height: 55,
        borderColor: '#ccc',
        borderWidth: 5,
        borderRadius: 20,
        marginBottom: 15,
        paddingHorizontal: 10,
        backgroundColor: '#bc1e0c',
    },
});
