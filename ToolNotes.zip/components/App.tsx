import React, {
    useState,
    useEffect,
} from 'react';
import {
    Text,
    StyleSheet,
    SafeAreaView,
    View,
    TextInput,
    Dimensions,
    Alert,
    StatusBar,
    Pressable,
    ScrollView,
    Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useRouter } from 'expo-router';
import CreateScreen from '@/app/create';
import EntriesScreen from '../app/entries';
import RNPickerSelect from 'react-native-picker-select';

const Stack = createNativeStackNavigator();

export default function App() {
    return (
        <>
            <Stack.Navigator initialRouteName="Create">
                <Stack.Screen name="Create" component={CreateScreen} />
                <Stack.Screen name="Entries" component={EntriesScreen} />
            </Stack.Navigator>
        </>
    );
}

const logoImg = require('../assets/images/TNLogo.png')



const { width, height } = Dimensions.get('window');
const styles = StyleSheet.create({
    main: {
        flex: 1,
        backgroundColor: '#fdf7dd',
        alignItems: 'center',
    },

    h1Wrapper: {
        backgroundColor: '#fdf7dd',
        width: '100%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingHorizontal: width * 0.05,
    },

    h1: {
        backgroundColor: '#fdf7dd',
        color: 'black',
        fontSize: 48,
        fontWeight: 'bold',
        padding: width * 0.05,
        paddingTop: height * 0.05,
        textAlign: 'center',
        textShadowColor: '#bc1e0c',
        textShadowOffset: { width: 2, height: 2 },
        textShadowRadius: 10,
        fontFamily: 'serif',
    },

    logo: {
        width: width * .2,
        height: height * .1,
    },

    lineBreak: {
        width: '100%',
        height: 2,
        backgroundColor: 'black',
    },

    h2Wrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        width: '90%',
        marginTop: 0,
    },

    h2: {
        fontSize: 30,
        fontWeight: 'bold',
        textAlign: 'left',
        textShadowColor: '#bc1e0c',
        textShadowOffset: { width: 2, height: 2 },
        textShadowRadius: 10,
        fontFamily: 'serif',
    },

    formWrapper: {
        width: '90%',
        marginTop: 20,
    },

    input: {
        height: 50,
        borderColor: '#ccc',
        borderWidth: 1,
        borderRadius: 0,
        marginTop: 15,
        marginBottom: 15,
        paddingHorizontal: 10,
        backgroundColor: '#fff',
    },

    textArea: {
        height: 100,
        textAlignVertical: 'top',
    },

    buttonRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 20,
        alignItems: 'flex-end',
        width: '50%',
    },

    button: {
        flex: 1,
        paddingVertical: 12,
        marginHorizontal: 5,
        width: 150,
        marginLeft: 'auto',
        borderRadius: 5,
        alignItems: 'center',
    },

    buttonText: {
        color: 'black',
        fontSize: 16,
        fontWeight: 'normal',
    },

    viewButton: {
        marginTop: 10,
        paddingVertical: 8,
        paddingHorizontal: 15,
        borderRadius: 5,
        alignSelf: 'flex-start',
    },

    viewButtonText: {
        color: 'black',
        fontSize: 16,
        fontWeight: 'normal',
    },

    scrollContent: {
        alignItems: 'center',
        paddingBottom: 20,
    },

});

const pickerSelectStyles = StyleSheet.create({

    inputIOS: {
        height: 55,
        borderColor: '#ccc',
        borderWidth: 1,
        borderRadius: 5,
        marginBottom: 15,
        paddingHorizontal: 10,
        backgroundColor: '#bc1e0c',
    },
    inputAndroid: {
        height: 55,
        borderColor: '#ccc',
        borderWidth: 5,
        borderRadius: 20,
        marginBottom: 15,
        paddingHorizontal: 10,
        backgroundColor: '#bc1e0c',
    },
});