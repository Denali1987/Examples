import { DarkTheme, DefaultTheme, ThemeProvider } from '@react-navigation/native';
import 'react-native-reanimated';
import React, { useEffect, useState } from 'react';
import * as SplashScreen from 'expo-splash-screen';
import { useColorScheme } from 'react-native';
import { useFonts } from 'expo-font';
import { StatusBar } from 'expo-status-bar';
import { Slot } from 'expo-router';

SplashScreen.preventAutoHideAsync(); // Prevent auto hiding at the start

export default function RootLayout() {
  const colorScheme = useColorScheme();
  const [loaded] = useFonts({
    SpaceMono: require('../assets/fonts/SpaceMono-Regular.ttf'),
  });

  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    if (loaded) {
      console.log("Fonts loaded, ready to hide splash screen.");
      setIsReady(true);
    }
  }, [loaded]);

  useEffect(() => {
    if (isReady) {
      setTimeout(() => {
        SplashScreen.hideAsync();
      }, 1000); // Delay hiding by 1 second
    }
  }, [isReady]);

  if (!isReady) {
    return null; // Prevents the app from rendering until everything is ready
  }

  return (
    <ThemeProvider value={colorScheme === 'dark' ? DarkTheme : DefaultTheme}>
      <StatusBar style={colorScheme === 'dark' ? 'light' : 'dark'} />
      <Slot />
    </ThemeProvider>
  );
}
