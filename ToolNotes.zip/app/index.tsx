import { router } from 'expo-router';
import { SafeAreaView, View, Text, TextInput, Pressable, ScrollView, StatusBar, Image } from 'react-native';
import { styles } from '../styles/styles';
import logoImg from '../assets/images/TNLogo.png';
import { Audio } from 'expo-av';
import { useEffect } from 'react';

export default function Index() {
    useEffect(() => {
        const playStartSound = async () => {
            const { sound } = await Audio.Sound.createAsync(
                require('../assets/audio/ToolNotesJingle1.mp3')
            );
            await sound.playAsync();
        };
        playStartSound();
    }, []);

    return (

        <SafeAreaView style={styles.main}>
            <StatusBar
                barStyle="dark-content"
                translucent={false}
                backgroundColor="#bc1e0c"
            />

            <View style={styles.h1Wrapper}>
                <Image source={logoImg} style={styles.logo} />
                <Text style={styles.h1}>Tool Notes</Text>
            </View>




            <View style={styles.h2Wrapper}>
                <Text style={styles.h2}>Home</Text>
            </View>

            <View style={styles.h2Wrapper}>

                <Pressable
                    style={({ pressed }) => [
                        styles.viewButton,
                        { backgroundColor: pressed ? '#a3c9a8' : '#0c7fbc', marginTop: 20 },
                    ]}
                    onPress={() => router.push('/create')}
                >
                    <Text style={styles.viewButtonText}>Create Entry</Text>
                </Pressable>

                <Pressable
                    style={({ pressed }) => [
                        styles.viewButton,
                        { backgroundColor: pressed ? '#a3c9a8' : '#0c7fbc', marginTop: 20 },
                    ]}
                    onPress={() => router.push('/entries')}
                >
                    <Text style={styles.viewButtonText}>View Entries</Text>
                </Pressable>
            </View>

            <View style={styles.lineBreak} />

            <ScrollView contentContainerStyle={styles.scrollContent} style={{ width: '100%' }}>
                <View style={styles.h2Wrapper}>
                    <Text style={styles.entryLabel}>Famous Qoute:</Text>
                </View>
                <View style={styles.h2Wrapper}>
                    <Text style={styles.entryText}>"Tool Notes! Yeah eee yeah!"</Text>
                    <Text style={styles.entryText}>~Muddy Waters</Text>
                </View>

            </ScrollView>
        </SafeAreaView >
    );
}
