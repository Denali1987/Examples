import React, { useState } from 'react';
import { SafeAreaView, View, Text, TextInput, Pressable, ScrollView, StatusBar, Image } from 'react-native';
import RNPickerSelect from 'react-native-picker-select';
import { styles, pickerSelectStyles } from '../styles/styles';
import logoImg from '../assets/images/TNLogo.png';
import { useRouter } from 'expo-router';



const CreateScreen = () => {

    const [designNo, setDesignNo] = useState('');
    const [processNo, setProcessNo] = useState('');
    const [reject, setReject] = useState('');
    const [comment, setComment] = useState('');
    const [spares, setSpares] = useState('');

    const designNoOptions = [
        { label: 'D314752A', value: 'D314752A' },
        { label: 'D200096G', value: 'D200096G' },
        { label: 'D2023337', value: 'D2023337' },
    ];
    const processNoOptions = [
        { label: 'SB115', value: 'SB115' },
        { label: 'SI630', value: 'SI630' },
        { label: 'SI306', value: 'SI306' },
    ];
    const rejectOptions = [
        { label: 'Dimensional', value: 'Dimensional' },
        { label: 'Cosmetic', value: 'Cosmetic' },
        { label: 'Supplier', value: 'Supplier' },
    ];
    const sparesForDesign = {
        'D314752A': [
            { label: '61', value: '61' },
            { label: '38', value: '38' },
        ],
        'D200096G': [
            { label: '156', value: '156' },
            { label: '324', value: '156' },
        ],
        'D2023337': [
            { label: '221', value: '221' },
            { label: '222', value: '222' },
        ]
    }

    const availableSpares = sparesForDesign[designNo] || [];
    const router = useRouter();

    return (
        <SafeAreaView style={styles.main}>
            <StatusBar
                barStyle="dark-content"
                translucent={false}
                backgroundColor="#bc1e0c"
            />

            <View style={styles.h1Wrapper}>
                <Image source={logoImg} style={styles.logo} />
                <Text style={styles.h1}>Tool Notes</Text>
            </View>



            <View style={styles.h2Wrapper}>
                <Text style={styles.h2}>Create Entry</Text>
            </View>
            <View style={styles.h2Wrapper}>
                <Pressable
                    style={({ pressed }) => [
                        styles.viewButton,
                        { backgroundColor: pressed ? '#a3c9a8' : '#0c7fbc' },
                    ]}
                    onPress={() => router.push('/entries')}
                >
                    <Text style={styles.viewButtonText}>View Entries</Text>
                </Pressable>
                <Pressable
                    style={({ pressed }) => [
                        styles.viewButton,
                        { backgroundColor: pressed ? '#a3c9a8' : '#0c7fbc' },
                    ]}
                    onPress={() => router.push('/')}
                >
                    <Text style={styles.viewButtonText}>Home</Text>
                </Pressable>
            </View>

            <View style={styles.lineBreak} />

            <ScrollView contentContainerStyle={styles.scrollContent} style={{ width: '100%' }}>



                <View style={styles.formWrapper}>
                    <RNPickerSelect
                        placeholder={{ label: 'Select Process Number', value: null }}
                        value={processNo}
                        onValueChange={(value) => setProcessNo(value)}
                        items={processNoOptions}
                        style={pickerSelectStyles}
                    />
                    <RNPickerSelect
                        placeholder={{ label: 'Select Reject', value: null }}
                        value={reject}
                        onValueChange={(value) => setReject(value)}
                        items={rejectOptions}
                        style={pickerSelectStyles}
                    />
                    <RNPickerSelect
                        placeholder={{ label: 'Select Design Number', value: null }}
                        value={designNo}
                        onValueChange={(value) => setDesignNo(value)}
                        items={designNoOptions}
                        style={pickerSelectStyles}
                    />
                    <RNPickerSelect
                        items={availableSpares}
                        placeholder={{ label: 'Select Spare', value: null }}
                        value={spares}
                        onValueChange={(value) => setSpares(value)}
                        style={{
                            inputIOS: {
                                paddingLeft: 30,
                                marginLeft: 30,
                                backgroundColor: '#bc1e0c',
                                borderRadius: 5,
                                borderWidth: 2,
                                borderColor: 'black',
                                height: 55,
                            },
                            inputAndroid: {
                                paddingLeft: 30,
                                marginLeft: 30,
                                backgroundColor: '#bc1e0c',
                                borderRadius: 5,
                                borderWidth: 2,
                                borderColor: 'black',
                                height: 55,
                            },
                        }}
                    />

                    <TextInput
                        style={[styles.input, styles.textArea]}
                        placeholder="Enter comment"
                        value={comment}
                        onChangeText={setComment}
                        multiline
                        numberOfLines={5}
                    />

                    <View style={styles.buttonRow}>
                        <Pressable
                            style={({ pressed }) => [
                                styles.button,
                                { backgroundColor: pressed ? '#a3c9a8' : '#0c7fbc' },
                            ]}
                            onPress={() => console.log('Submit Entry Pressed')}
                        >
                            <Text style={styles.buttonText}>Submit Entry</Text>
                        </Pressable>
                    </View>

                </View>
            </ScrollView>


        </SafeAreaView>
    )
};

export default CreateScreen;