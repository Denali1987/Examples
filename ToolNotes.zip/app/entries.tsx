import React from 'react';
import { View, Text, FlatList, SafeAreaView, Pressable, StatusBar, Image, ScrollView } from 'react-native';
import { styles } from '../styles/styles';
import { router } from 'expo-router';
import logoImg from '../assets/images/TNLogo.png';

const dummyEntries = [
  {
    id: '1',
    processNo: 'SB115',
    designNo: 'D314752A',
    reject: 'Dimensional',
    comment: 'Tool chipped on station 3.',
    spares: '61',
  },
  {
    id: '2',
    processNo: 'SI630',
    designNo: 'D200096G',
    reject: 'Supplier',
    comment: 'Wrong material used.',
    spares: '324',
  },
  {
    id: '3',
    processNo: 'SI630',
    designNo: 'D200096G',
    reject: 'Supplier',
    comment: 'Wrong material used.',
    spares: '324',
  },
  {
    id: '4',
    processNo: 'SI630',
    designNo: 'D200096G',
    reject: 'Cosmetic',
    comment: 'Stop bump was high, took .001" out of stop bump diesection, barbered mating punch.',
    spares: '',
  },
];

const EntriesScreen = () => {
  return (
    <SafeAreaView style={styles.main}>
      <StatusBar
        barStyle="dark-content"
        translucent={false}
        backgroundColor="#bc1e0c"
      />

      <View style={styles.h1Wrapper}>
        <Image source={logoImg} style={styles.logo} />
        <Text style={styles.h1}>Tool Notes</Text>
      </View>



      <View style={styles.h2Wrapper}>
        <Text style={styles.h2}>Entries</Text>
      </View>

      <View style={styles.h2Wrapper}>

        <Pressable
          style={({ pressed }) => [
            styles.viewButton,
            { backgroundColor: pressed ? '#a3c9a8' : '#0c7fbc', marginTop: 20 },
          ]}
          onPress={() => router.push('/create')}
        >
          <Text style={styles.viewButtonText}>Create Entry</Text>
        </Pressable>

        <Pressable
          style={({ pressed }) => [
            styles.viewButton,
            { backgroundColor: pressed ? '#a3c9a8' : '#0c7fbc', marginTop: 20 },
          ]}
          onPress={() => router.push('/')}
        >
          <Text style={styles.viewButtonText}>Home</Text>
        </Pressable>
      </View>

      <View style={styles.lineBreak} />


      <FlatList
        data={dummyEntries}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.entry}>
            <Text style={styles.entryText}>
              <Text style={styles.entryLabel}>Process #: </Text>
              {item.processNo}
            </Text>

            <Text style={styles.entryText}>
              <Text style={styles.entryLabel}>Design #: </Text>
              {item.designNo}
            </Text>

            <Text style={styles.entryText}>
              <Text style={styles.entryLabel}>Reject: </Text>
              {item.reject}
            </Text>

            <Text style={styles.entryText}>
              <Text style={styles.entryLabel}>Comment: </Text>
              {item.comment}
            </Text>

            <Text style={styles.entryText}>
              <Text style={styles.entryLabel}>Spare Used: </Text>
              {item.spares}
            </Text>
          </View>
        )}
      />





    </SafeAreaView>
  );
};

export default EntriesScreen;
