import React, {
    useState,
    useEffect,
} from 'react';
import {
    Text,
    StyleSheet,
    SafeAreaView,
    View,
    TextInput,
    Dimensions,
    Alert,
    StatusBar,
    Pressable,
    ScrollView,
    Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const weightsImg = require('../assets/images/weights.png')

const App = () => {
    const [weight, setWeight] = useState('');
    const [height, setHeight] = useState('');
    const [bmi, setBmi] = useState<number | null>(null);
    const [showResult, setShowResult] = useState(false);
    const [isPressed, setIsPressed] = useState(false);

    // store/recall bmi
    useEffect(() => {
        const loadData = async () => {
            try {
                const savedWeight = await AsyncStorage.getItem('weight');
                const savedHeight = await AsyncStorage.getItem('height');
                const savedBmi = await AsyncStorage.getItem('bmi');

                if (savedWeight && savedHeight && savedBmi) {
                    setWeight(savedWeight);
                    setHeight(savedHeight);
                    setBmi(parseFloat(savedBmi));
                    setShowResult(true);
                }
            } catch (e) {
                console.error('Failed to load data from AsyncStorage:', e);
            }
        };

        loadData();
    }, []);

    // Calculation and store
    const calculate = async () => {
        const heightInches = parseFloat(height);
        const weightPounds = parseFloat(weight);

        if (isNaN(heightInches) || isNaN(weightPounds) || heightInches <= 0 || weightPounds <= 0) {
            Alert.alert("Bad entry, Try again using valid numbers >0.");
            return;
        }

        const BMI = (weightPounds / Math.pow(heightInches, 2)) * 703;
        setBmi(BMI.toFixed(2));
        setShowResult(true);

        try {
            await AsyncStorage.setItem('weight', weight);
            await AsyncStorage.setItem('height', height);
            await AsyncStorage.setItem('bmi', BMI.toFixed(2));
        } catch (e) {
            console.error('Failed to save data: ', e);
        }
    };

    return (
        <SafeAreaView style={styles.main}>

            {/* make the status bar the same as the assignment */}
            <StatusBar
                barStyle="dark-content"
                translucent={false}
                backgroundColor="#f4511e"
            />

            {/* Header */}
            <View style={styles.headerWrapper}>
                <Text style={styles.h1}>BMI Calculator</Text>
            </View>

            {/* weight in pounds input field */}
            <TextInput
                style={styles.input}
                placeholder="Weight in Pounds"
                keyboardType="numeric"
                value={weight}
                onChangeText={setWeight}
            />

            {/* height in inches input field */}
            <TextInput
                style={styles.input}
                placeholder="Height in Inches"
                keyboardType="numeric"
                value={height}
                onChangeText={setHeight}
            />

            {/* calculate button */}
            <Pressable style={[styles.button, { backgroundColor: isPressed ? '#2c3e50' : '#34495e' }]}
                onPressIn={() => setIsPressed(true)} // when pressed
                onPressOut={() => {
                    setIsPressed(false);
                    calculate();
                }}

            // when released
            >
                <Text style={styles.buttonText}>Compute BMI</Text>
            </Pressable>


            {/* scroll area below the inputs and pressable */}
            <ScrollView style={{ width: '100%' }} contentContainerStyle={{ alignItems: 'center' }}>
                <View style={styles.resultContainer}>
                    <Text style={[styles.resultText, { opacity: showResult ? 1 : 0 }]}>
                        Body Mass Index is {bmi}
                    </Text>
                </View>

                {/* BMI classes/categories */}
                <View style={styles.bmiCategoryContainer}>
                    <Text style={styles.bmiCategoryHeader}>Assessing Your BMI</Text>
                    <View>
                        <Text style={styles.bmiCategoryText}>
                            Underweight: less than 18.5{'\n'}
                            Healthy: 18.5 to 24.9{'\n'}
                            Overweight: 25.0 to 29.9{'\n'}
                            Obese: 30.0 or higher{'\n'}
                        </Text>
                    </View>

                    {/* filler to accentuate the scrollview */}
                    <View>
                        <Text style={styles.bmiCategoryText}>
                            Lorem ipsum dolor sit amet consectetur adipiscing elit.
                            Quisque faucibus ex sapien vitae pellentesque sem placerat.
                            In id cursus mi pretium tellus duis convallis. Tempus
                            leo eu aenean sed diam urna tempor. Pulvinar vivamus
                            fringilla lacus nec metus bibendum egestas. Iaculis
                            massa nisl malesuada lacinia integer nunc posuere.
                            Ut hendrerit semper vel class aptent taciti sociosqu.
                            Ad litora torquent per conubia nostra inceptos himenaeos.
                        </Text>
                    </View>

                    {/* and an image to further accentuate the scrollview */}
                    <Image
                        source={weightsImg}
                        style={[styles.weightImg]}
                    />
                </View>
            </ScrollView>
        </SafeAreaView >
    );
};

export default App;

const { width, height } = Dimensions.get('window');

const styles = StyleSheet.create({
    main: {
        flex: 1,
        backgroundColor: 'white',
        alignItems: 'center',
        paddingTop: StatusBar.currentHeight,
    },

    headerWrapper: {
        backgroundColor: '#f4511e',
        width: '100%',
    },

    h1: {
        backgroundColor: '#f4511e',
        color: 'white',
        fontSize: 28,
        fontWeight: 'bold',
        padding: width * 0.05,
        paddingTop: height * 0.05,
        textAlign: 'center',
    },

    input: {
        width: '95%',
        padding: width * 0.03,
        marginVertical: height * .01,
        borderWidth: 0,
        borderRadius: 5,
        fontSize: 24,
        color: '#b9bdbd',
        backgroundColor: '#ecf0f1',
    },

    button: {
        width: '95%',
        backgroundColor: '#34495e',
        paddingVertical: 10,
        borderRadius: 5,
        marginVertical: height * .01,
    },

    buttonText: {
        color: 'white',
        fontSize: 24,
        textAlign: 'center',
    },

    resultContainer: {
        marginTop: height * .07,
    },

    resultText: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#333',

    },

    bmiCategoryContainer: {
        width: '95%',
        alignItems: 'flex-start',
        marginTop: height * .09,
    },

    bmiCategoryHeader: {
        fontSize: 20,
    },

    bmiCategoryText: {
        fontSize: 20,
        paddingLeft: width * 0.05,
    },

    weightImg: {
        width: '100%',
        height: 200,
        resizeMode: 'contain',
        alignSelf: 'center',
        marginBottom: 10,
    }
});
